﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Element_Found_in_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] {7,3,8,28,9 };
            Console.WriteLine("Enter the Numbere to Search :- ");
            int num = int.Parse(Console.ReadLine());

            bool found = true;
            for (int i = 0; i < arr.Length; i++)
            {
                if (num == arr[i])
                {
                    found = true;
                    break;
                }
            }

            if (found)
            {
                Console.WriteLine("Element Found");
            }
            else
            {
                Console.WriteLine("Element Not Found");
            }

        }
    }
}
