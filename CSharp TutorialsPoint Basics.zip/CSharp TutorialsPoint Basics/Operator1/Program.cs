﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 15, b = 42, c = 5;
            
            // *,+
            int d = a + b * c;
            
            Console.WriteLine("\nD :- " + d);

            int marks = 72, max = 80;
            int perc = marks  * 100/ max;
            Console.WriteLine("\nPerc :- " + perc);

            int e = 14;
            e = e + 5; //Unary Operator
            Console.WriteLine("\nE :- " + e);

            int f = 14;
            f += 5; //Assignmnet Operator
            Console.WriteLine("\nF :- " + f);

            int g = 14;
            g++;
            Console.WriteLine("\nG :- " + g);

            int h = 14;
            ++h;
            Console.WriteLine("\nH :- " + h);

            int i = 14;
            int j = ++i;
            Console.WriteLine("\nI :- "+i);
            Console.WriteLine("J :- " + j);

            int k = 14;
            int l = k++;
            Console.WriteLine("\n K :- "+k);
            Console.WriteLine(" L :- " + l);
            


        }
    }
}
