﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodPassByReference
{
    class Program
    {
        static void SampleMethod(ref int x)
        {
            Console.WriteLine("Initial Value Of Formal Parameter :- " + x);
            Console.WriteLine();
            x = 100;
            Console.WriteLine("Final Value Of Formal Parameter :- " + x);
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            int a = 10;
            Console.WriteLine("Initial Value of actual parameter :- " + a);
            Console.WriteLine();

            SampleMethod(ref a);
            Console.WriteLine("Final value of actual parameter :- " + a);
        }
    }
}
