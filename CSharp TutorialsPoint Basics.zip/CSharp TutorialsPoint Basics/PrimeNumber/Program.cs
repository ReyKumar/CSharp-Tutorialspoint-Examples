﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.Write("Enter a Value to check a number is Prime Or Not :- ");
            int num = int.Parse(Console.ReadLine());
            bool isPrime = true;

            for (int i = 2; i <= Math.Sqrt(num); i++)
            {
                if(num % i==0)
                {
                    isPrime = false;
                    break;
                }

                if(isPrime)
              
                    Console.WriteLine("Number is Prime");
              
                else
              
                    Console.WriteLine("Number is Not Prime");
              
            }

            Console.ReadLine();
        }
    }
}
