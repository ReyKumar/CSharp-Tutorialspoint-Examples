﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empty_Statement
{
    class Program
    {
        private bool done;

        static void Main(string[] args)
        {

        }
        void ProcessMessages()
        {
           
                ; // Statement needed here.
        }

        void F()
        {
            //...
            if (done) goto exit;
            //...
            exit:
            ; // Statement needed here.
        }
    }
}
