﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GOTOStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
        abc:
            Console.WriteLine(i);
            i++;
            if (i<=10)
            {
                goto abc;
            }
        }
    }
}
