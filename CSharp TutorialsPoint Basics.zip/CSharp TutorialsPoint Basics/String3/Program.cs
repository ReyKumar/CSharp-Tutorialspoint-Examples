﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String3
{
    class Program
    {
        static void Main(string[] args)
        {
            string company = "Top make in India Products";
            Console.WriteLine(company.StartsWith("To")); //True
            Console.WriteLine(company.StartsWith("TO")); //False

            Console.WriteLine(company.EndsWith("ts")); // True
            Console.WriteLine(company.EndsWith("Ts")); // False
        }
    }
}
