﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayForEach
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] { 7,3,9,4,8,1};
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }
}
