﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter User Name :- ");
            string username = Console.ReadLine();

            Console.Write("Enter Password :- ");
            string password = Console.ReadLine();

            string valid = (username == "Ronak" && password == "Hi") ? "Welcome Ronak" : "Invalid Entry";
            Console.WriteLine(valid);


        }
    }
}
