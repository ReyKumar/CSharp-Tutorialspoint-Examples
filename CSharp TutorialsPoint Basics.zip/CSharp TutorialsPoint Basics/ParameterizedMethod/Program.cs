﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedMethod
{
    class Program
    {
        static void add(int x, int y) // Formal Argument
        {
            int sum = x + y;
            Console.WriteLine("The Sum of A & B is " + sum); 
        }

        static void sub(int a = 23, int b = 24) // With Value
        {
            int substraction = a - b;
            Console.WriteLine("Sub of A And B :- " + substraction);
        }

        static  int  mul() 
        {
            int a = 24, b = 47;
            int multi = a * b;
            
            Console.WriteLine(multi);
            return multi;
        }

        static float div(float x, float y)
        {
            float division = x / y;
            return division;
            // Console.WriteLine("The Division of A And B is " +division);
        }

        static void Main(string[] args)
        {
            int num1 = 53, num2 = 46;
            Console.WriteLine("Pass By Reference");
            add(num1, num2); // Actual Argument
            Console.WriteLine();

            Console.WriteLine("Pass By Value");
            add(25, 46);
            Console.WriteLine();

            Console.WriteLine("Sub Method");
            sub();
            Console.WriteLine();

            Console.WriteLine("Mul Method");
            mul();
            Console.WriteLine();

            Console.WriteLine("Div Method");
            float d1 = 68, d2 = 45;
            float result = div(d1,d2);

            Console.WriteLine("The Division of A And B is " + result);

        }
    }
}
