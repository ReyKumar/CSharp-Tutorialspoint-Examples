﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodCommunication
{
    class Program
    {
        static char GetGrade()
        {

            float percent = GetPercentage();
            if (percent >= 80)
            {
                return 'A';
            }

            else if (percent >= 60)
            {
                return 'B';
            }
            else if (percent >= 40)
            {
                return 'C';
            }

            else
            {
                return 'D';
            }
        }

        static  float   GetPercentage()
        {
            float TotalMarks = GetTotal();

            float percentage = TotalMarks * 100 / 300;
            return percentage;
        }

        static float GetTotal()
        {
            Console.Write("Enter Mark 1 :- ");
            float marks1 = float.Parse(Console.ReadLine());

            Console.Write("Enter Mark 2 :- ");
            float marks2 = float.Parse(Console.ReadLine());

            Console.Write("Enter Mark 3 :- ");
            float marks3 = float.Parse(Console.ReadLine());

            float Total = marks1 + marks2 + marks3;
            return Total;


        }

        static void Main(string[] args)
        {
            Console.WriteLine("Grade :- "+GetGrade());
        }
    }
}
