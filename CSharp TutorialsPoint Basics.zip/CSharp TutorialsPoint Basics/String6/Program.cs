﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String6
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "My Name is Ronak Sankhala";
            Console.WriteLine(str.IndexOf("is", StringComparison.CurrentCultureIgnoreCase));
            Console.WriteLine(str.Length);
        }
    }
}
