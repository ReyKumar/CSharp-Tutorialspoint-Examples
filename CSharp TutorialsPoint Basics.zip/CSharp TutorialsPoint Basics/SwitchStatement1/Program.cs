﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchStatement1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a Character :- ");
            char ch = char.Parse(Console.ReadLine());
            string s = ch.ToString().ToLower();

            switch (s)
            {
                case "a":
                case "e":
                case "i":
                case "o":
                case "u":
                    Console.WriteLine(s + " is Vowel");
                    break;
                default:
                    Console.WriteLine(s+" is Constant Or Special Symbol");
                    break;
            }
        }
    }
}
