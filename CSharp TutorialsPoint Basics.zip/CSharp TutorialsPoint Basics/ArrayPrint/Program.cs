﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrint
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] { 9,7,5,15,4,8};
            Console.WriteLine("Simple Array");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}
