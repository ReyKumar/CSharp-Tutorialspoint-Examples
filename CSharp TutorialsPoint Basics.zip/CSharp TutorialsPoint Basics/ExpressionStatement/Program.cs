﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            int radius = 3;

            // Expression statement (assignment).
            double area = 3.14 * (radius * radius);

            // Error. Not  statement because no assignment:
            //circ * 2;

            // Expression statement (method invocation).
            System.Console.WriteLine();

            // Expression statement (new object creation).
            System.Collections.Generic.List<string> strings = new List<string>();

            Console.WriteLine(area);

        }
    }
}
