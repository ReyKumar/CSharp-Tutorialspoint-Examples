﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a Character :- ");
            char ch = char.Parse(Console.ReadLine());

            string s = ch.ToString().ToLower();

            switch (s)
            {
                case "a":
                    Console.WriteLine(s + " is Vowel");
                    break;

                case "e":
                    Console.WriteLine(s + " is Vowel");
                    break;

                case "i":
                    Console.WriteLine(s + " is Vowel");
                    break;

                case "o":
                    Console.WriteLine(s + " is Vowel");
                    break;

                case "u":
                    Console.WriteLine(s + " is Vowel");
                    break;


                default:
                    Console.WriteLine(s +" is Constant Or Special Character");
                    break;
            }

        }
    }
}
