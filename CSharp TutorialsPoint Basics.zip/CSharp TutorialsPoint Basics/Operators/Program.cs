﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" \t :- \t :- \t :- \t :- Arithmatic Operation -: \t -: \t -: \t -: \t ");
            
                
                    Console.WriteLine("Enter Value Of A :- ");
                    int valueOfA = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Value Of B :- ");
                    int valueOfB = int.Parse(Console.ReadLine());

            int Sum = valueOfA + valueOfB;
            Console.WriteLine("The Sum Of A And B is {0}", Sum);

            int Sub = valueOfA - valueOfB;
            Console.WriteLine("The Substraction Of A And B is {0}", Sub);

            int Mul = valueOfA * valueOfB;
            Console.WriteLine("The Multiplication Of A And B is {0}", Mul);

            int Div = valueOfA / valueOfB;
            Console.WriteLine("The Division Of A And B is {0}", Div);

            int Mod = valueOfA % valueOfB;
            Console.WriteLine("The Modulus Of A And B is {0}", Mod);


            Console.WriteLine(" \n \n \t :- \t :- \t :- \t :- Relational Operation -: \t -: \t -: \t -: \t ");

            Console.Write("Enter Value of A :- ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Enter Value of B :- ");
            int b = int.Parse(Console.ReadLine());
            if (a>b)
            {
                Console.WriteLine("A is Bigger then B");
            }
            else
            {
                Console.WriteLine("B is Bigger then A");
            }

            Console.WriteLine(" \n \n \t :- \t :- \t :- \t :- Logical Operation -: \t -: \t -: \t -: \t ");

            Console.Write("Enter Value of A :- ");
            int A = int.Parse(Console.ReadLine());
            Console.Write("Enter Value of B :- ");
            int B = int.Parse(Console.ReadLine());
            Console.Write("Enter Vlaue Of C :- ");
            int C = int.Parse(Console.ReadLine());
            if (A > B && A > C)
            {
                Console.WriteLine("A is the Largest Value");
            }

            else if (B > A && B > C)
            {
                Console.WriteLine("B is the Largest Value");
            }

            else if(C > A && C > B)
            {
                Console.WriteLine("C is the Largest Value");
            }

            Console.ReadLine();


        }
    }
}
