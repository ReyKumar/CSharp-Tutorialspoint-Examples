﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace string2
{
    class Program
    {
        static void Main(string[] args)
        {

            string company = "Top make in India Products";
            string lower = company.ToLower();
            string upper = company.ToUpper();

            Console.WriteLine(company);
            Console.WriteLine(lower);
            Console.WriteLine(upper);

        }
    }
}
