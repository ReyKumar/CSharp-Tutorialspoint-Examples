﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String5
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "My Name is Ronak Sankhala";
            string upper = str.ToUpper();

            Console.WriteLine(str.Equals(upper, StringComparison.CurrentCultureIgnoreCase)); // True
            Console.WriteLine(str.Equals(upper)); // False
        }
    }
}
