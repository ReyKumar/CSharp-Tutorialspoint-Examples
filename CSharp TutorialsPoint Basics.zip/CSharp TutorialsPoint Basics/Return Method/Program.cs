﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Return_Method
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter The First Number :- ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Enter The Number :- ");
            int b = int.Parse(Console.ReadLine());

            if (b == 0)
            {
                Console.WriteLine("Can't Devide by Zero");
                return;
            }

            int div = a / b;

            Console.WriteLine("The Result is "+div);


        }
    }
}
