﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indroduction
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Ronak";
            int age = 22;

            // There are three way to print Varibles
            // 1st Method
            Console.WriteLine("The User Name is " + name);
            Console.WriteLine("Age of the user " + age);

            //2nd Method
            Console.WriteLine("The User Name is " + name + " \nAge of the user " + age);

            //3rd Method
            Console.WriteLine("The User Name is {0} \nAge of the user {1}", name, age);

            UserInput input = new UserInput();
            input.result();
        }

    }
}
