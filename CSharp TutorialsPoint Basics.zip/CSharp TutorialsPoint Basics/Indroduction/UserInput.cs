﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indroduction
{
    class UserInput
    {
        string name = Console.ReadLine();
        int Age = int.Parse(Console.ReadLine());

        public void result()
        {
            Console.WriteLine("Your Name is {0} And Your Age is {1}", name, Age);
        }
    }
}
