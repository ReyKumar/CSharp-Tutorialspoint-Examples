﻿#define PI
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreProcessor_Directive
{
    class Program
    {
        static void Main(string[] args)
        {
#if (PI)
            Console.WriteLine("PI is Defined");

#else
	    
                Console.WriteLine("PI is Not Defined");
        
#endif
        }
    }
}
