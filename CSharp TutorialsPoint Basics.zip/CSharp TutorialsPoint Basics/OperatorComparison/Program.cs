﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorComparison
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 50, b = 40;
            Console.WriteLine(a > b);
            Console.WriteLine(a < b);
            Console.WriteLine(a >= b);
            Console.WriteLine(a <= b);
            Console.WriteLine(a == b);
            Console.WriteLine(a != b);
            Console.WriteLine();

            int num = 46;
            string s = num % 2 == 0 ? "Even" : "Odd";

            Console.WriteLine(s);
            Console.WriteLine();

            Console.WriteLine("AND Operator");
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine(true && true);
            Console.WriteLine(true && false);
            Console.WriteLine(false && true);
            Console.WriteLine(false && false);

            Console.WriteLine();

            Console.WriteLine("OR Operator");
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine(true  || true);
            Console.WriteLine(true  || false);
            Console.WriteLine(false || true);
            Console.WriteLine(false || false);

            Console.WriteLine();
        }
    }
}
