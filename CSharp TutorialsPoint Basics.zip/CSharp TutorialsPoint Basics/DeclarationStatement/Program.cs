﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclarationStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variable declaration statements.
            double area;
            double radius = 2;

            // Constant declaration statement.
            const double pi = 3.14159;

            area = pi * radius * radius;
            Console.WriteLine("Radius :- " + radius);
            Console.WriteLine("pi :- " + pi);

            Console.WriteLine("Area :- "+area);
        }
    }
}
