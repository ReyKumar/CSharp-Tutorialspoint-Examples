﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeCasting
{
    class Program
    {
        static void Main(string[] args)
        {
            short num1 = 10;
            short num2 = 30;

            short sum = (short)(num1 + num2);
            Console.WriteLine(sum);

            /* Boxing & UnBoxing */
            boxingUnBoxing();
            
        }
      public static  void boxingUnBoxing()
        {
            Console.WriteLine("This is the Example of Boxing");
            int a = 20;
            object o = a; // Boxing

            // Small dataType to 
            int b = (int)o; // UnBoxing

            Console.WriteLine("Value Of A :- {}", a);
            Console.WriteLine("Value Of O :- {}", o);
            Console.WriteLine("Value Of B :- {}", b);

        }
    }
}
