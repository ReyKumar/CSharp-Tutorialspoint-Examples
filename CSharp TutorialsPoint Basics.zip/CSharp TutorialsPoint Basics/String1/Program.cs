﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String1
{
    class Program
    {
        static void Main(string[] args)
        {
            string fname, lname;
            fname = "Ronak";
            lname = " Sankhala";

            string fullName = fname + lname;
            Console.WriteLine("My Full Name is {0}",fullName);

            string puraName = string.Concat(fname, lname);
            Console.WriteLine("Mera Pura nam :- {0}",puraName);

            // By using string Constructor
            char[] letters = {'H','e','l','l','o'};
            string greetings = new string(letters);
            Console.WriteLine("Greetings :- {0}",greetings);

            char[] ch = greetings.ToCharArray();
            Console.WriteLine(ch);

            // Methid Returning string
            string[] sarray = {"Hello"," From","Visual Studio", };
            string message = String.Join(" ", sarray);
            Console.WriteLine("Message : {0}",message);

            // Formatting Method to Convert a Value 
            DateTime waiting = new DateTime(2017,10,10,17,58,1);
            string chat = String.Format("Message Sent at {0:t} on {0:D}",waiting);
            Console.WriteLine("Message :- {0}",chat);


        }
    }
}
