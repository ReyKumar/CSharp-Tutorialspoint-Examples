﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilder1
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Ronak ";
            str = str + "Sankhala";

            Console.WriteLine(str);
        }
    }
}
