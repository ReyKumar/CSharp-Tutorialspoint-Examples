﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jagged_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] arr = new int[3][];
            arr[0] = new int[3] {60,47,32 };
            arr[1] = new int[2] { 10, 68 };
            arr[2] = new int[4] {47,58,48,95 };

            foreach (var ar in arr)
            {
                foreach (var item in ar)
                {
                    Console.Write(item +"\t");
                }
                Console.WriteLine();
            }
        }
    }
}
