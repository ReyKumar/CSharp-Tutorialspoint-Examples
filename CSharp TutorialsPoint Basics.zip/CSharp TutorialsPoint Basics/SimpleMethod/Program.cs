﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleMethod
{
    class Program
    {
        static  void SimpleMethod()
        {
            Console.WriteLine("Run Simple Method");
        }
        static void Main(string[] args)
        {
            SimpleMethod();
        }
    }
}
