﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodPassByParams
{
    class Program
    {
        static int Add(int num1,int num2,params int[] list)
        {
            int sum = num1 + num2;
            foreach (var item in list)
            {
                sum += item;
            }
            return sum;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Add(25,251,25, -1000,  745, 5));
            Console.WriteLine();
        }
    }
}
