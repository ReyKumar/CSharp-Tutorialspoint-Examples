﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOptionalParameter
{
    class Program
    {
        static float RectangleArea(float height, float width= 10)
        {
            float Area = height * width;
            return Area;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Without Optional Parameter");
            float result = RectangleArea(height: 10.5f);
            Console.WriteLine(result);
            Console.WriteLine();
            Console.WriteLine("With Optional Parameter");
            float Result = RectangleArea(height:15, width: 45);
            Console.WriteLine(Result);
        }
    }
}
