﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilder2
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Ronak ";
            StringBuilder sb = new StringBuilder(str);
            sb.Append("Sankhala");
            Console.WriteLine(sb);
        }
    }
}
