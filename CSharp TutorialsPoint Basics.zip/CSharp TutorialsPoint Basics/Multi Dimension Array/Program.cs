﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Dimension_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[3, 4] { {2,8,4,4 }, { 8,4,5,9},{3,5,4,1 } };
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(arr[i,j] + "\t");

                }
                Console.WriteLine();
            }
        }
    }
}
